gas_display


local gasDisplay = false

RegisterCommand("gas", function()
    gasDisplay = not gasDisplay
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local playerPed = PlayerPedId()
        local vehicle = GetVehiclePedIsIn(playerPed, false)
        
        if IsPedInAnyVehicle(playerPed, false) then
            local fuelLevel = GetVehicleFuelLevel(vehicle)
            
            if gasDisplay then
                DrawText3D(GetEntityCoords(playerPed).x, GetEntityCoords(playerPed).y, GetEntityCoords(playerPed).z + 1.0, "Fuel: " .. string.format("%.2f", fuelLevel) .. "L")
            end
        end
    end
end)

function DrawText3D(x, y, z, text)
    local onScreen,_x,_y = World3dToScreen2d(x, y, z)
    local px,py,pz = table.unpack(GetGameplayCamCoords())
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 255)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x,_y)
    local factor = (string.len(text)) / 370
    DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 41, 11, 41, 68)
end



To install this script on your FiveM server, follow these steps:

Navigate to your FiveM server's resource folder. This is typically located in the resources directory of your FiveM server installation.
Create a new folder inside the resources directory and name it something like gas_display.
Inside the gas_display folder, create a new text file named __resource.lua.
Open the __resource.lua file with a text editor and add the following line: client_script 'gas_display.lua'.
Save the __resource.lua file and close the text editor.
Inside the gas_display folder, create another text file named gas_display.lua.
Copy the Lua script provided above and paste it into the gas_display.lua file.
Save the gas_display.lua file and close the text editor.
Restart your FiveM server to apply the changes.
Once the server has restarted, players can use the /gas command in the chat to toggle the display of the gas amount while they are in a vehicle. The gas amount will be displayed above the vehicle in the game world.